# Import library
from textblob import TextBlob
import nltk
import sys

# Ensure NLTK data is downloaded
nltk.download('punkt')

# Define sentiment analysis function
def analyze_sentiment(review):
    analysis = TextBlob(review)
    if analysis.sentiment.polarity > 0:
        return "positif"
    elif analysis.sentiment.polarity < 0:
        return "negatif"
    else:
        return "netral"

# Main function to get sentiment
if __name__ == "__main__":
    review = sys.argv[1]
    sentiment = analyze_sentiment(review)
    print(sentiment)
