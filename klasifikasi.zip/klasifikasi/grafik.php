<?php
$servername = "localhost";
$username = "root"; // Ganti dengan username database Anda
$password = ""; // Ganti dengan password database Anda
$dbname = "dashboard";

// Membuat koneksi ke database
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Mengambil data dari database
$sql = "SELECT month, value FROM chart_data ORDER BY id ASC";
$result = $conn->query($sql);

$months = [];
$values = [];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $months[] = $row["month"];
        $values[] = $row["value"];
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Line Graph</title>
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        /* Style sebelumnya tetap ada */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Montserrat', sans-serif;
            font-size: medium;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            background-color: #f0f0f0;
            color: #333;
        }

        header {
            background: linear-gradient(90deg, #51c4e4, #51c4e4);
            color: white;
            padding: 1rem 0;
            text-align: center;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        header h1 {
            font-size: 2rem;
            margin: 0;
            animation: fadeInDown 1s;
        }

        .container {
            width: 80%;
            margin: 2rem auto;
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            flex: 1;
            text-align: left;
        }

        h2 {
            color: #51c4e4;
            font-size: 2rem;
            margin-bottom: 1rem;
            position: relative;
            padding-bottom: 0.5rem;
        }

        h2::after {
            content: '';
            position: absolute;
            width: 50px;
            height: 4px;
            background-color: #51c4e4;
            left: 0;
            bottom: -8px;
        }

        p {
            line-height: 1.8;
            font-size: 1.2rem;
            margin-bottom: 1.5rem;
            animation: fadeIn 1s;
        }

        a {
            background-color: #51c4e4;
            color: rgb(0, 0, 0);
            padding: 14px 25px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            margin-top: 1rem;
        }

        a:hover {
            background-color: #51c4e4;
        }

        canvas {
            max-width: 100%;
            margin: 2rem 0;
        }

        footer {
            text-align: center;
            padding: 1px;
            background-color: rgb(24, 23, 23);
            color: white;
          }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .container {
                width: 90%;
                padding: 1.5rem;
            }

            h2 {
                font-size: 2rem;
            }

            p {
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>Line Graph</h1>
    </header>
    <div class="container">
        <section>
            <h2>Data Visualization</h2>
            <p>This graph displays the data trends over time. By analyzing the data, we can identify patterns and make informed decisions. The line graph below provides a clear visualization of the trends over the past months.</p>
            <canvas id="lineChart" width="800" height="400"></canvas>
        </section>
        <a href="dashboard.html"><i class="fa fa-arrow-circle-o-left" style="font-size:24px"></i></a>
    </div>
    <footer>
        <p>Author: Syahra Fajarila</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const ctx = document.getElementById('lineChart').getContext('2d');
        const months = <?php echo json_encode($months); ?>;
        const values = <?php echo json_encode($values); ?>;
        
        const lineChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: months,
                datasets: [{
                    label: 'Data Set 1',
                    data: values,
                    borderColor: '#51c4e4',
                    backgroundColor: 'rgba(75, 248, 231, 0.2)',
                    borderWidth: 3,
                    pointBackgroundColor: '#51c4e4',
                    pointBorderColor: '#fff',
                    pointHoverRadius: 7,
                    pointHoverBackgroundColor: '#51c4e4',
                    pointHoverBorderColor: '#fff',
                    pointRadius: 5,
                    pointHitRadius: 10,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                scales: {
                    x: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Months'
                        }
                    },
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Values'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    },
                    tooltip: {
                        enabled: true
                    }
                }
            }
        });
    </script>
</body>
</html>
