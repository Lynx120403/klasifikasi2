<?php
$servername = "localhost";
$username = "root"; // Ganti dengan username database Anda
$password = ""; // Ganti dengan password database Anda
$dbname = "dashboard";

// Membuat koneksi ke database
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fungsi untuk menentukan sentimen menggunakan TextBlob (Python)
function getSentiment($review) {
    $command = escapeshellcmd("python sentiment_analysis.py \"$review\"");
    $output = shell_exec($command);
    return trim($output);
}

// Jika form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_name = $_POST['user_name'];
    $review = $_POST['review'];
    $sentiment = getSentiment($review);

    $sql = "INSERT INTO reviews (user_name, review, sentiment) VALUES ('$user_name', '$review', '$sentiment')";

    if ($conn->query($sql) === TRUE) {
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Mengambil ulasan dari database
$sql = "SELECT user_name, review, review_date, sentiment FROM reviews ORDER BY review_date DESC";
$result = $conn->query($sql);

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Halaman Ulasan</title>
    <style>
        body {
            font-family: 'Montserrat'; font-size: medium;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .review-form {
            display: flex;
            flex-direction: column;
        }
        .review-form label {
            margin-top: 10px;
            color: #555;
        }
        .review-form input, .review-form textarea {
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            width: 100%;
        }
        .review-form button {
            margin-top: 20px;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #51c4e4;
            color: #000000;
            font-size: 16px;
            cursor: pointer;
        }
        .review-form button:hover {
            background-color: #51c4e4;
        }
        .reviews {
            margin-top: 30px;
        }
        .review-item {
            background: #f9f9f9;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 15px;
        }
        .review-item h3 {
            margin: 0;
            color: #333;
        }
        .review-item p {
            margin: 10px 0 0;
            color: #555;
        }
        a {
            background-color: #51c4e4;
            color: rgb(0, 0, 0);
            padding: 14px 25px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            margin-top: 1rem;
        }
        a:hover {
            background-color: #51c4e4;
        }
        .prediction {
            background: #e3f7f5;
            padding: 15px;
            border: 1px solid #51c4e4;
            border-radius: 5px;
            margin-top: 30px;
            text-align: center;
        }
        .prediction h3 {
            color: #333;
        }
        .prediction p {
            color: #555;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Ulasan Produk</h1>
        <form class="review-form" method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
            <label for="user_name">Nama:</label>
            <input type="text" id="user_name" name="user_name" placeholder="Nama Anda" required>
            <label for="review">Ulasan:</label>
            <textarea id="review" name="review" rows="4" placeholder="Tulis ulasan Anda di sini" required></textarea>
            <button type="submit">Kirim Ulasan</button>
        </form>
        <div class="prediction">
            <h3>Prediksi Hasil Ulasan</h3>
            <p id="predictionResult">Belum ada prediksi.</p>
        </div>
        <div class="reviews">
            <h2>Ulasan Terbaru</h2>
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<div class='review-item'><h3>" . $row["user_name"]. "</h3><p>" . $row["review"]. "</p><small>" . $row["review_date"]. " - Sentimen: " . $row["sentiment"] . "</small></div>";
                }
            } else {
                echo "Belum ada ulasan.";
            }
            ?>
        </div>
        <a href="dashboard.html"><i class="fa fa-arrow-circle-o-left" style="font-size:24px"></i></a>
    </div>
</body>
</html>
